package com.totvs.byyou.sample.rest;

@javax.ws.rs.ApplicationPath("api/rest")
public class ApplicationConfig extends javax.ws.rs.core.Application {
}